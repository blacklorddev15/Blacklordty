// ============================================================
//   helper/buttons.js  –  native-flow interactive buttons
// ------------------------------------------------------------
//   Wire format taken from the reference build
//   (github.com/blacklorddev15/Tes-r-po -> Skylar X ULTRA panel).
//
//   blacklord-bttns' own sendButtons() is deliberately NOT used: its
//   README documents that a `viewOnceMessage` wrapper is required for
//   current WhatsApp clients to render native-flow buttons, but the
//   implementation never applies it. Without the wrapper the client
//   accepts the send and then silently drops the buttons -- no error,
//   no button. The message is therefore built and relayed here exactly
//   the way the reference does it.
// ============================================================
'use strict';

const baileys = require('blacklord-baileys');

// Some builds are transpiled ESM and keep everything under `default`.
const api = (baileys && baileys.default && typeof baileys.default === 'object'
  && Object.keys(baileys).length <= 1) ? baileys.default : baileys;

const { generateWAMessageFromContent, proto, prepareWAMessageMedia } = api;

function quickReply(displayText, id) {
  return {
    name: 'quick_reply',
    buttonParamsJson: JSON.stringify({ display_text: String(displayText), id: String(id) }),
  };
}

function ctaUrl(displayText, url) {
  return {
    name: 'cta_url',
    buttonParamsJson: JSON.stringify({
      display_text: String(displayText), url, merchant_url: url,
    }),
  };
}

/**
 * Send one interactive message: optional header image + body + buttons.
 * Buttons are `{ name, buttonParamsJson }`, i.e. already-built native-flow
 * buttons (see quickReply / ctaUrl).
 */
async function sendInteractiveButtons(sock, jid, {
  title, text, footer, buttons, quoted, imageMessage,
} = {}) {
  if (!proto) throw new Error('baileys proto unavailable');
  if (typeof generateWAMessageFromContent !== 'function') {
    throw new Error('generateWAMessageFromContent unavailable');
  }

  const header = proto.Message.InteractiveMessage.Header.fromObject({
    title: String(title || ''),
    hasMediaAttachment: !!imageMessage,
  });
  if (imageMessage) header.imageMessage = imageMessage;

  const interactive = proto.Message.InteractiveMessage.fromObject({
    body: proto.Message.InteractiveMessage.Body.fromObject({ text: String(text || '') }),
    footer: proto.Message.InteractiveMessage.Footer.fromObject({ text: String(footer || '') }),
    header,
    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
      messageVersion: 1,
      buttons: (buttons || []).map(b => ({
        name: b.name,
        buttonParamsJson: b.buttonParamsJson || JSON.stringify(b.params || {}),
      })),
    }),
  });

  const msg = await generateWAMessageFromContent(jid, {
    viewOnceMessage: {
      message: {
        messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
        interactiveMessage: interactive,
      },
    },
  }, { quoted, userJid: sock.user?.id });

  await sock.relayMessage(msg.key.remoteJid, msg.message, {
    messageId: msg.key.id,
    additionalNodes: [{
      tag: 'biz',
      attrs: {},
      content: [{
        tag: 'interactive',
        attrs: { type: 'native_flow', v: '1' },
        content: [{ tag: 'native_flow', attrs: { v: '9', name: 'mixed' } }],
      }],
    }],
  });

  return msg;
}

// ------------------------------------------------------------
//   Header image, uploaded once and reused.
//   WhatsApp media is addressed per upload, so a cached imageMessage
//   saves a media round trip on every .menu.
// ------------------------------------------------------------
const HEADER_TTL = 30 * 60 * 1000;
let _header = { key: null, imageMessage: null, at: 0 };

async function loadImageBuffer(src) {
  if (!src) return null;
  if (Buffer.isBuffer(src)) return src;
  if (typeof src !== 'string') return null;
  if (src.startsWith('data:')) {
    const b64 = src.split(',')[1];
    return b64 ? Buffer.from(b64, 'base64') : null;
  }
  if (src.startsWith('http')) {
    const axios = require('axios');
    const res = await axios.get(src, { responseType: 'arraybuffer', timeout: 12000 });
    return Buffer.from(res.data);
  }
  return require('fs').readFileSync(src);
}

async function headerImage(sock, src) {
  if (!src) return null;
  if (_header.key === src && _header.imageMessage && Date.now() - _header.at < HEADER_TTL) {
    return _header.imageMessage;
  }
  if (typeof prepareWAMessageMedia !== 'function') return null;

  let buf = null;
  try {
    buf = await loadImageBuffer(src);
  } catch (_) {
    return null;
  }
  // A truncated fetch is worse than no image at all.
  if (!buf || buf.length < 200) return null;

  try {
    const media = await prepareWAMessageMedia({ image: buf }, { upload: sock.waUploadToServer });
    const imageMessage = media && media.imageMessage;
    if (!imageMessage) return null;
    _header = { key: src, imageMessage, at: Date.now() };
    return imageMessage;
  } catch (_) {
    return null;
  }
}

module.exports = { sendInteractiveButtons, headerImage, quickReply, ctaUrl, api };
