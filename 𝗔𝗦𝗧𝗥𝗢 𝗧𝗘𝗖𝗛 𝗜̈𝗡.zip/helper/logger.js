'use strict';

const chalk = require('chalk');
const lolcat = (() => {
  try { return require('lolcatjs'); } catch { return null; }
})();

const BRAND = 'ASTROCORE';
const BOX_TOP = `┏━━━━━━━━━━━━━『  ${BRAND.padEnd(14)}  』━━━━━━━━━━━━━─`;
const BOX_BOTTOM = '┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━─ ⳹';

function skylarLog(message, color = 'white', isError = false) {
  const tag = chalk.blue.bold(`[ ${BRAND} ]`);
  const paint = typeof chalk[color] === 'function' ? chalk[color](String(message)) : String(message);
  const output = isError ? console.error : console.log;
  if (String(message).includes('\n') || String(message).includes('════')) output(tag, paint);
  else output(`${tag} ${paint}`);
}

global.log = global.log || skylarLog;

function banner(lines, rainbow = true) {
  const block = [BOX_TOP, ...lines, BOX_BOTTOM].join('\n');
  if (rainbow && lolcat && typeof lolcat.fromString === 'function') {
    try { lolcat.fromString(block); return; } catch (_) {}
  }
  console.log(chalk.cyan(block));
}

const icons = {
  text: '💬', image: '🖼 ', video: '🎥', audio: '🎵', sticker: '🌀',
  document: '📄', location: '📍', contact: '👤', reaction: '❤️', poll: '📊',
  viewOnce: '👁 ', unknown: '❓'
};

function getMsgType(message) {
  if (!message) return 'unknown';
  if (message.conversation || message.extendedTextMessage) return 'text';
  if (message.imageMessage) return 'image';
  if (message.videoMessage) return 'video';
  if (message.audioMessage) return 'audio';
  if (message.stickerMessage) return 'sticker';
  if (message.documentMessage) return 'document';
  if (message.locationMessage) return 'location';
  if (message.contactMessage) return 'contact';
  if (message.reactionMessage) return 'reaction';
  if (message.pollCreationMessage) return 'poll';
  if (message.viewOnceMessage || message.viewOnceMessageV2) return 'viewOnce';
  return 'unknown';
}

function getMsgText(message) {
  if (!message) return '';
  if (message.conversation) return message.conversation;
  if (message.extendedTextMessage?.text) return message.extendedTextMessage.text;
  if (message.imageMessage?.caption) return message.imageMessage.caption;
  if (message.videoMessage?.caption) return message.videoMessage.caption;
  if (message.documentMessage?.caption) return message.documentMessage.caption;
  if (message.reactionMessage?.text) return message.reactionMessage.text;
  if (message.pollCreationMessage?.name) return message.pollCreationMessage.name;
  if (message.locationMessage) {
    return `[${Number(message.locationMessage.degreesLatitude).toFixed(4)}, ${Number(message.locationMessage.degreesLongitude).toFixed(4)}]`;
  }
  return message.contactMessage?.displayName || '';
}

function logMessage(messageInfo, chatMeta = {}) {
  try {
    const raw = messageInfo?.message || {};
    let message = raw;
    for (const wrapper of ['ephemeralMessage', 'viewOnceMessage', 'viewOnceMessageV2', 'viewOnceMessageV2Extension']) {
      if (message?.[wrapper]?.message) message = message[wrapper].message;
    }
    const type = getMsgType(message);
    const senderJid = String(messageInfo?.key?.participant || messageInfo?.key?.remoteJid || '');
    const sender = senderJid.split('@')[0].split(':')[0].replace(/\D/g, '') || senderJid;
    const name = messageInfo?.pushName || sender;
    const jid = messageInfo?.key?.remoteJid || '';
    const isGroup = jid.endsWith('@g.us');
    const isChannel = jid.endsWith('@newsletter');
    const timestamp = Number(messageInfo?.messageTimestamp || 0) * 1000 || Date.now();
    const date = new Date(timestamp);
    const tz = process.env.TZ || 'Africa/Nairobi';
    const time = date.toLocaleTimeString('en-GB', { timeZone: tz, hour12: false });
    const day = date.toLocaleDateString('en-GB', { timeZone: tz, weekday: 'long' });
    const dateText = date.toLocaleDateString('en-GB', { timeZone: tz });
    const lines = [
      `»  Sent Time: ${day}, ${time}`,
      `»  Date: ${dateText}`,
      `»  Message Type: ${icons[type] || icons.unknown} ${type}`,
      `»  Sender Name: ${name}`,
      `»  Chat ID: ${jid.split('@')[0]}`
    ];
    if (isGroup) {
      lines.push(`»  Group: ${chatMeta.groupName || '(unknown)'}`);
      lines.push(`»  Group JID: ${jid.split('@')[0]}`);
    } else {
      lines.push(`»  Chat: ${isChannel ? 'CHANNEL' : 'DM'}`);
    }
    const text = getMsgText(message).slice(0, 300);
    if (text) lines.push(`»  Message: ${text}`);
    banner(lines);
  } catch (_) {
    // Logging must never interrupt message handling.
  }
}

const logInfo = (label, message) => skylarLog(`[INFO]  ${label}${message ? ` – ${message}` : ''}`, 'cyan');
const logSuccess = (label, message) => skylarLog(`[OK]    ${label}${message ? ` – ${message}` : ''}`, 'green');
const logWarn = (label, message) => skylarLog(`[WARN]  ${label}${message ? ` – ${message}` : ''}`, 'yellow', true);
const logError = (label, message) => skylarLog(`[ERR]   ${label}${message ? ` – ${message}` : ''}`, 'red', true);
const logSession = (sessionId, status) => {
  const dot = status === 'connected' ? '🟢' : status === 'reconnecting' ? '🟡' : '🔴';
  skylarLog(`session : ${sessionId} ${dot} ${status}`, 'white');
};

module.exports = {
  BRAND, skylarLog, banner, logMessage, logInfo, logSuccess, logWarn, logError,
  logSession, getMsgType, getMsgText
};
