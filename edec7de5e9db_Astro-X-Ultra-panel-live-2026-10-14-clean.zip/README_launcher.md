<div align="center">
  <h1>ASTRO X ULTRA</h1>
  <a href="https://git.io/typing-svg">
    <img src="https://readme-typing-svg.demolab.com?font=Rockwell&size=45&pause=1000&color=33ff00&center=true&width=800&height=80&lines=Astro+X+Ultra;Multi+Device+Whatsapp+Bot;Made+by+blacklord" alt="Typing SVG" />
  </a>
</div>

<div align="center">
  <img src="./utils/bot_image.jpg" alt="ASTRO X ULTRA" height="250">
</div>

---

<div align="center">
  <img src="https://readme-typing-svg.demolab.com/?lines=The+bot+supports+deployment;On+all+free+panels+easily" alt="Typing SVG" />
</div>

---

> Quick Actions

<div align="center">

| Action | Link |
|--------|------|
| **Fork Repository** | <a href="https://github.com/blacklorddev15/Weuh/fork"><img src="https://img.shields.io/badge/Fork Repo%20-24292e?style=for-the-badge&logo=github&logoColor=white&logoSize=auto"/></a> |
| **Download ZIP** | <a href="https://github.com/blacklorddev15/Weuh/archive/refs/heads/main.zip"><img src="https://img.shields.io/badge/Download%20-2ea043?style=for-the-badge&logo=github&logoColor=white&logoSize=auto"/></a> |

</div>

---

> 🌐 Deployment Options

<div align="center">

| Platform | Button |
|----------|--------|
| **Heroku** | <a href="https://dashboard.heroku.com/new?template=https://github.com/blacklorddev15/Weuh"><img src="https://img.shields.io/badge/HerokuHosting-6762A6?style=for-the-badge&logo=heroku&logoColor=white&logoSize=auto"/></a> |
| **Railway** | <a href="https://railway.app/new"><img src="https://img.shields.io/badge/Railway-000000?style=for-the-badge&logo=railway&logoColor=white&logoSize=auto"/></a> |
| **Render** | <a href="https://render.com"><img src="https://img.shields.io/badge/Render-0099ff?style=for-the-badge&logo=render&logoColor=white&logoSize=auto"/></a> |
| **CypherXHost** | <a href="https://platform.cypherx.store/register?ref=REPLI2955E16C9A"><img src="https://img.shields.io/badge/CypherXHosting-007BFF?style=for-the-badge&logo=cypherxhost&logoColor=white&logoSize=auto"/></a> |

</div>

---

> 🔑 Session & Pairing

<div align="center">

| Method | Button |
|--------|--------|
| **Pairing code** | After deployment, use `.pair <number>` in WhatsApp to request a code. |

</div>

---

> 💬 Support & Community

<div align="center">

| Platform | Link |
|----------|------|
| **WhatsApp Group** | <a href="https://whatsapp.com/channel/0029VbBzXBN2kNFoxm7LiG3Q"><img src="https://img.shields.io/badge/WhatsApp%20Group-25D366?style=for-the-badge&logo=whatsapp&logoColor=white&logoSize=auto"/></a> |
| **YouTube** | <a href="#"><img src="https://img.shields.io/badge/YouTube-FF0000?style=for-the-badge&logo=youtube&logoColor=white&logoSize=auto"/></a> |
| **Telegram** | <a href="t.me/supremLord"><img src="https://img.shields.io/badge/Telegram-0088cc?style=for-the-badge&logo=telegram&logoColor=white&logoSize=auto"/></a> |

</div>

---

<div align="center">
  <sub>Built with ❤️ by <a href="https://github.com/blacklorddev15">blacklord</a></sub>
</div>
