/**
 * Sticker → command bindings.
 *
 * Ported from the Astro Inc. build's `.setsticker`: reply to a sticker with
 * `.setsticker menu` and sending that sticker alone then runs `.menu`.
 * Unlike the per-group sticker *actions* in utils/stickerTrigger.js, these
 * bindings are global (a sticker works in any chat) and live in the bot
 * settings store under `stickerCommands`.
 */
const database = require('../database');

const SKIP_KEYS = ['messageContextInfo', 'protocolMessage', 'senderKeyDistributionMessage'];
const WRAPPERS = ['ephemeralMessage', 'viewOnceMessage', 'viewOnceMessageV2', 'viewOnceMessageV2Extension', 'documentWithCaptionMessage'];

function toBase64Hash(raw) {
  if (!raw) return null;
  if (Buffer.isBuffer(raw)) return raw.toString('base64');
  if (raw instanceof Uint8Array) return Buffer.from(raw).toString('base64');
  if (typeof raw === 'object') return Buffer.from(Object.values(raw)).toString('base64');
  return null;
}

function resolveContent(message) {
  if (!message) return null;
  const keys = Object.keys(message).filter(k => !SKIP_KEYS.includes(k));
  const top = keys[0];
  if (!top) return null;
  if (WRAPPERS.includes(top)) return message[top]?.message || null;
  return message;
}

/* The sticker in this message, either sent directly or quoted in the reply. */
function stickerFrom(msg) {
  const content = resolveContent(msg && msg.message);
  if (!content) return null;
  if (content.stickerMessage) return content.stickerMessage;
  const keys = Object.keys(content).filter(k => !SKIP_KEYS.includes(k));
  const quoted = (keys.length ? content[keys[0]]?.contextInfo : null)?.quotedMessage;
  if (!quoted) return null;
  const quotedContent = resolveContent(quoted);
  return (quotedContent && quotedContent.stickerMessage) || null;
}

function prints(sticker) {
  return [toBase64Hash(sticker?.fileSha256), toBase64Hash(sticker?.fileEncSha256)].filter(Boolean);
}

function all() {
  const map = database.getBotSetting('stickerCommands');
  return map && typeof map === 'object' ? map : {};
}

function set(name, sticker) {
  const map = { ...all() };
  map[String(name).toLowerCase()] = {
    fileSha256: toBase64Hash(sticker?.fileSha256) || null,
    fileEncSha256: toBase64Hash(sticker?.fileEncSha256) || null
  };
  database.setBotSetting('stickerCommands', map);
  return map;
}

function remove(name) {
  const map = { ...all() };
  const key = String(name).toLowerCase();
  if (!(key in map)) return false;
  delete map[key];
  database.setBotSetting('stickerCommands', map);
  return true;
}

/* Which bound command does this message carry? `available` is the live command map. */
function match(msg, available) {
  const sticker = stickerFrom(msg);
  if (!sticker) return null;
  const here = prints(sticker);
  if (!here.length) return null;
  for (const [name, stored] of Object.entries(all())) {
    const storedPrints = [stored?.fileSha256, stored?.fileEncSha256].filter(Boolean);
    if (storedPrints.some(p => here.includes(p))) {
      if (!available || available.has(name)) return name;
    }
  }
  return null;
}

module.exports = { all, set, remove, match, stickerFrom, prints, toBase64Hash, resolveContent };
