'use strict';

/**
 * Fake quote layer — ported from the Astro Inc. build (`case.js` of the
 * Blacklordty repo) so replies look the same here.
 *
 *   ownerCard()   the owner's contact card, faked onto a WhatsApp status. A reply
 *                 sent quoting this shows as a reply to that card.
 *   fakeStatus    a fake WhatsApp status. Plain text sends quote this.
 *
 * Both are ordinary Baileys `quoted` payloads — nothing is actually posted to
 * anyone's status; the key is faked so WhatsApp renders it that way.
 */

const config = require('../config');

function vcardQuote(displayName, waid) {
  const name = String(displayName || '').trim() || 'ASTROCORE X';
  const number = String(waid || '').split('@')[0].split(':')[0].replace(/[^0-9]/g, '');
  return {
    key: {
      fromMe: false,
      participant: '0@s.whatsapp.net',
      remoteJid: 'status@broadcast'
    },
    message: {
      contactMessage: {
        displayName: name,
        vcard: `BEGIN:VCARD
VERSION:3.0
N:;${name};;;;
FN:${name}
item1.TEL;waid=${number}:${number}
item1.X-ABLabel:Ponsel
END:VCARD`
      }
    }
  };
}

/** The owner's card, built from config ownerName[0] / ownerNumber[0]. */
function ownerCard() {
  const list = Array.isArray(config.ownerName) ? config.ownerName : [config.ownerName];
  const numbers = Array.isArray(config.ownerNumber) ? config.ownerNumber : [config.ownerNumber];
  const name = list.filter(Boolean)[0] || config.botName || 'ASTROCORE X';
  const number = numbers.filter(Boolean)[0] || '';
  return vcardQuote(name, number);
}

const fakeStatus = {
  key: {
    remoteJid: 'status@broadcast',
    fromMe: false,
    id: 'FakeID12345',
    participant: '0@s.whatsapp.net'
  },
  message: {
    conversation: config.botName || 'ASTROCORE X'
  }
};

module.exports = { vcardQuote, ownerCard, fakeStatus };
