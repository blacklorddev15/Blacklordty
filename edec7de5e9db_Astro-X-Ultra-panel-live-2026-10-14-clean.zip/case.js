'use strict';

/**
 * case.js — your own command table.
 *
 * Loaded by index.js and called for every incoming message BEFORE the normal
 * command loader, so a command written here needs no file in commands/ and no
 * plugin. Add a `case`, restart, done.
 *
 * Contract:
 *     return true   -> the message was yours; nothing else runs
 *     return false  -> not one of your cases; the normal command loader takes over
 *
 * Everything a command file normally gets is built for you below:
 *     text, command, args     parsed from the message (prefix already stripped)
 *     from, sender, isGroup   where it came from
 *     reply(x)                reply in the same chat, quoting the message
 *     isOwnerSender           true for the numbers in config.js ownerNumber,
 *                             and for anything sent from the bot's own account
 *     prefix                  the live prefix from config.js
 *
 * NOTE: an error thrown in here is caught and logged, and the message is then
 * handed to the normal loader — a broken case can never take the bot down.
 */

const config = require('./config');

/** Text of a message, whatever shape it arrived in. */
function extractText(msg) {
  const m = (msg && msg.message) || {};
  return (
    m.conversation ||
    m.extendedTextMessage?.text ||
    m.imageMessage?.caption ||
    m.videoMessage?.caption ||
    m.buttonsResponseMessage?.selectedDisplayText ||
    m.listResponseMessage?.title ||
    m.templateButtonReplyMessage?.selectedDisplayText ||
    ''
  );
}

/** "+254 705 894 984:12@s.whatsapp.net" -> "254705894984" */
function normalizeNumber(jid) {
  return String(jid || '').split('@')[0].split(':')[0].replace(/\D/g, '');
}

function ownerNumbers() {
  const list = Array.isArray(config.ownerNumber) ? config.ownerNumber : [config.ownerNumber];
  return list.filter(Boolean).map(n => String(n).replace(/\D/g, ''));
}

async function handle(sock, msg) {
  try {
    const from = msg?.key?.remoteJid;
    if (!from || from === 'status@broadcast') return false;

    const text = extractText(msg).trim();
    if (!text) return false;

    const prefix = config.prefix === '' ? '' : config.prefix || '.';
    if (prefix && !text.startsWith(prefix)) return false;

    const body = prefix ? text.slice(prefix.length).trim() : text;
    if (!body) return false;
    const [rawCommand, ...args] = body.split(/\s+/);
    const command = rawCommand.toLowerCase();

    const sender = msg.key?.participant || from;
    const isGroup = String(from).endsWith('@g.us');
    const isOwnerSender = !!msg.key?.fromMe || ownerNumbers().includes(normalizeNumber(sender));
    const reply = (content, options = {}) =>
      sock.sendMessage(from, typeof content === 'string' ? { text: content } : content, {
        quoted: msg,
        ...options
      });

    switch (command) {
      // ─────────── EXAMPLE 1: a plain reply (delete or keep) ───────────
      case 'hello':
        await reply('👋 Hello from case.js — this command lives here, not in commands/.');
        return true;

      // ─────────── EXAMPLE 2: owner-only, with arguments (delete) ───────────
      case 'echo':
        if (!isOwnerSender) {
          await reply('👑 Owner only.');
          return true;
        }
        await reply(args.length ? args.join(' ') : 'Give me something to echo: .echo hi');
        return true;

      // ─────────── EXAMPLE 3: what the command can see (delete) ───────────
      case 'whoami':
        await reply(
          `*sender:* ${sender}\n` +
            `*number:* ${normalizeNumber(sender)}\n` +
            `*group:* ${isGroup ? 'yes' : 'no'}\n` +
            `*owner:* ${isOwnerSender ? 'yes' : 'no'}\n` +
            `*prefix:* ${prefix || 'none'}`
        );
        return true;

      // ▼▼▼▼▼▼▼▼▼▼ ADD NEW COMMANDS HERE ▼▼▼▼▼▼▼▼▼▼
      // case 'yourcommand':
      //   // args are already split for you
      //   await reply('whatever you want to send');
      //   return true;
      //
      // case 'sendimage':
      //   await reply({ image: { url: 'https://example.com/x.jpg' }, caption: 'hi' });
      //   return true;
      // ▲▲▲▲▲▲▲▲▲▲ ADD NEW COMMANDS HERE ▲▲▲▲▲▲▲▲▲▲

      default:
        return false; // not ours — let the normal command loader run
    }
  } catch (error) {
    console.error('[case.js] error:', error && error.message);
    return false;
  }
}

module.exports = handle;
