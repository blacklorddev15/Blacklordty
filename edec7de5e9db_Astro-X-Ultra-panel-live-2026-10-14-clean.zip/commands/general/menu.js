const config = require('../../config');
const { loadCommands } = require('../../utils/commandLoader');
const { generateWAMessageFromContent } = require('@whiskeysockets/baileys');
const { sendButtons } = require('gifted-btns');
const { applyFont } = require('../../utils/fontConverter');
const { ownerCard } = require('../../utils/quotes');
const fs = require('fs');
const path = require('path');
const os = require('os');

const MENU_SETTINGS_FILE = path.join(__dirname, '../../data/menuSettings.json');
const MENU_ORDER = require('../../data/menuCommandOrder.json');

const detectPlatform = () => {
  if (process.env.RAILWAY_ENVIRONMENT || process.env.RAILWAY_PROJECT_ID) return '🚉 Railway';
  if (process.env.DYNO) return '☁️ Heroku';
  if (process.env.RENDER) return '⚡ Render';
  if (process.env.REPL_ID || process.env.REPL_SLUG) return '🔵 Replit';
  if (process.env.PREFIX && process.env.PREFIX.includes('termux')) return '📱 Termux';
  if (process.env.PORTS && process.env.CYPHERX_HOST_ID) return '🌀 CypherX Platform';
  if (process.env.P_SERVER_UUID) return '🖥️ Panel';
  if (process.env.LXC) return '📦 Linux Container (LXC)';
  switch (os.platform()) {
    case 'win32': return '🪟 Windows';
    case 'darwin': return '🍎 macOS';
    case 'linux': return '🐧 Linux';
    default: return '❓ Unknown';
  }
};

function getMenuStyle() {
  const valid = ['1', '2', '3'];
  try {
    const runtimeSettings = require('../../utils/settings');
    const fromStore = runtimeSettings.get('menuStyle');
    if (fromStore && valid.includes(String(fromStore))) return String(fromStore);
    if (!fs.existsSync(MENU_SETTINGS_FILE)) return '1';
    const stored = JSON.parse(fs.readFileSync(MENU_SETTINGS_FILE, 'utf8')).menuStyle;
    return valid.includes(String(stored)) ? String(stored) : '1';
  } catch {
    return '1';
  }
}

function formatUptime() {
  const seconds = Math.floor(process.uptime());
  const days = Math.floor(seconds / 86400);
  const hours = Math.floor((seconds % 86400) / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const remainingSeconds = seconds % 60;
  const parts = [];
  if (days) parts.push(`${days}d`);
  if (hours) parts.push(`${hours}h`);
  if (minutes) parts.push(`${minutes}m`);
  parts.push(`${remainingSeconds}s`);
  return parts.join(' ');
}

function formatMemory(bytes) {
  if (bytes >= 1073741824) return `${(bytes / 1073741824).toFixed(2)} GB`;
  if (bytes >= 1048576) return `${(bytes / 1048576).toFixed(1)} MB`;
  return `${(bytes / 1024).toFixed(0)} KB`;
}

const progressBar = (used, total, size = 10, withPercent = true) => {
  const tail = (pct) => (withPercent ? ` ${pct}%` : '');
  if (!total) return `[${'░'.repeat(size)}]${tail(0)}`;
  const percentage = Math.max(0, Math.min(100, Math.round((used / total) * 100)));
  const filled = Math.round((percentage / 100) * size);
  return `[${'█'.repeat(filled)}${'░'.repeat(size - filled)}]${tail(percentage)}`;
};

const CATEGORY_TO_SECTION = {
  owner: 'owner',
  admin: 'admin',
  general: 'settings',
  ai: 'ai',
  media: 'media',
  fun: 'fun',
  anime: 'anime',
  ephoto: 'design',
  ephoto360: 'ephoto360',
  convert: 'convert',
  tools: 'tools',
  utility: 'utility',
  movies: 'movies',
  reaction: 'reaction',
  religion: 'religeon',
  religeon: 'religeon',
  sports: 'sports',
  textmaker: 'textmaker'
};

const LATIN_LOWER = 'abcdefghijklmnopqrstuvwxyz';
const SERIF_ITALIC_LOWER = [...'𝑎𝑏𝑐𝑑𝑒𝑓𝑔ℎ𝑖𝑗𝑘𝑙𝑚𝑛𝑜𝑝𝑞𝑟𝑠𝑡𝑢𝑣𝑤𝑥𝑦𝑧'];
const SERIF_ITALIC_UPPER = [...'𝐴𝐵𝐶𝐷𝐸𝐹𝐺𝐻𝐼𝐽𝐾𝐿𝑀𝑁𝑂𝑃𝑄𝑅𝑆𝑇𝑈𝑉𝑊𝑋𝑌𝑍'];
const SERIF_BOLD_UPPER = [...'𝐀𝐁𝐂𝐃𝐄𝐅𝐆𝐇𝐈𝐉𝐊𝐋𝐌𝐍𝐎𝐏𝐐𝐑𝐒𝐓𝐔𝐕𝐖𝐗𝐘𝐙'];

function normalizeCommandName(name) {
  return String(name || '').normalize('NFKD').replace(/\p{M}/gu, '').toLowerCase();
}

const SAMPLE_NAME_SECTION = new Map();
const SAMPLE_NAME_ORDER = new Map();
for (const section of MENU_ORDER.sections) {
  const sectionOrder = new Map();
  section.commands.forEach((name, index) => {
    const normalizedName = normalizeCommandName(name);
    sectionOrder.set(normalizedName, index);
    if (!SAMPLE_NAME_SECTION.has(normalizedName)) SAMPLE_NAME_SECTION.set(normalizedName, section.key);
  });
  SAMPLE_NAME_ORDER.set(section.key, sectionOrder);
}

function mapLetters(text, lowerMap, upperMap) {
  return [...String(text)].map(char => {
    const lowerIndex = LATIN_LOWER.indexOf(char.toLowerCase());
    if (lowerIndex < 0) return char;
    if (char === char.toUpperCase()) return upperMap[lowerIndex] || char;
    return lowerMap[lowerIndex] || char;
  }).join('');
}

function styleCommandName(name) {
  return mapLetters(name, SERIF_ITALIC_LOWER, SERIF_ITALIC_UPPER);
}

function titleCaseName(name) {
  return String(name).toLowerCase().replace(/(^|[\s_-])([a-z])/g, (_, separator, letter) => `${separator}${letter.toUpperCase()}`);
}

function buildMenuText(commandList, totalCount, speed) {
  const prefix = config.prefix || '.';
  const bot = config.botName || 'ASTRO X ULTRA';
  const botTitle = mapLetters(bot.toUpperCase(), SERIF_ITALIC_UPPER, SERIF_BOLD_UPPER);
  const botFooter = styleCommandName(titleCaseName(bot));
  const ownerName = (Array.isArray(config.ownerName) ? config.ownerName[0] : config.ownerName) || 'blacklord';
  const hostName = detectPlatform();
  const { getModeLabel } = require('../../utils/botMode');
  const currentMode = getModeLabel();
  const totalMemory = os.totalmem();
  const botUsedMemory = process.memoryUsage().rss;
  const systemUsedMemory = totalMemory - os.freemem();
  const readmore = String.fromCharCode(8206).repeat(4001);
  const ping = Number.isInteger(speed) ? `${speed}` : speed.toFixed(2);
  const ramUsedPercent = totalMemory ? Math.max(0, Math.min(100, Math.round((systemUsedMemory / totalMemory) * 100))) : 0;
  const connected = global.isBotConnected !== false;

  const groups = new Map(MENU_ORDER.sections.map(section => [section.key, []]));
  const extraSections = new Map();
  for (const command of commandList) {
    const normalizedName = normalizeCommandName(command.name);
    const category = String(command.category || 'general').toLowerCase();
    const sectionKey = SAMPLE_NAME_SECTION.get(normalizedName) || CATEGORY_TO_SECTION[category];
    if (groups.has(sectionKey)) {
      groups.get(sectionKey).push(command);
    } else {
      const key = `extra:${category}`;
      if (!extraSections.has(key)) {
        extraSections.set(key, {
          key,
          label: category.replace(/[-_]/g, ' ').toUpperCase(),
          display: styleCommandName(category.replace(/[-_]/g, ' ').toUpperCase()),
          commands: []
        });
      }
      extraSections.get(key).commands.push(command);
    }
  }

  const orderedSections = MENU_ORDER.sections
    .map(section => ({ ...section, commands: groups.get(section.key) }))
    .filter(section => section.commands.length > 0)
    .concat([...extraSections.values()].sort((a, b) => a.label.localeCompare(b.label)));

  let menu = `•━═ 〘  _*~${botTitle}~*_   〙═━•\n\n`;
  menu += ' ╭═━⪩〘 𝑺𝒀𝑺𝑻𝑬𝑴 𝑺𝑻𝑨𝑻𝑼𝑺 〙••⩵꙰ཱི࿐\n';
  menu += ` │⫹⫺ 𝗖𝗢𝗥𝗘: _*~${botTitle}~*_ ${connected ? '🟢' : '🔴'}\n`;
  menu += ` │⫹⫺ 𝗕𝗨𝗜𝗟𝗗 𝗜𝗗: v${config.version || '3.0.0'}\n`;
  menu += ` │⫹⫺ 𝗢𝗪𝗡𝗘𝗥: ${styleCommandName(ownerName)}\n`;
  menu += ` │⫹⫺ 𝗢𝗣𝗘𝗥𝗔𝗧𝗜𝗢𝗡: 🌐 🔒 ${styleCommandName(currentMode)}\n`;
  menu += ` │⫹⫺ 𝗨𝗣𝗧𝗜𝗠𝗘: ⏱️ ${formatUptime()}\n`;
  menu += ` │⫹⫺ 𝗦𝗣𝗘𝗘𝗗: ${ping} ms\n`;
  menu += ` │⫹⫺ 𝗧𝗢𝗢𝗟𝗦𝗘𝗧: ${totalCount}\n`;
  menu += ` │⫹⫺ 𝗤𝗨𝗜𝗖𝗞 𝗞𝗘𝗬: ${prefix}\n`;
  menu += ` │⫹⫺ 𝗡𝗘𝗧𝗪𝗢𝗥𝗞: ${styleCommandName(hostName)}\n`;
  menu += ` │⫹⫺ 𝗕𝗢𝗧 𝗠𝗘𝗠𝗢𝗥𝗬: ${formatMemory(botUsedMemory)}\n`;
  menu += ` │⫹⫺ 𝗦𝗩𝗥 𝗥𝗔𝗠: ${progressBar(systemUsedMemory, totalMemory, 10, false)}\n`;
  menu += ` │⫹⫺ 𝗥𝗔𝗠 𝗨𝗦𝗘𝗗: ${ramUsedPercent}%\n`;
  menu += ' ╰━━━━━━━━━━━━•⩵꙰ཱི࿐\n\n';
  menu += `${readmore}\n`; // Read more — everything below collapses behind the button
  menu += ' •═〘 𝑪𝑶𝑴𝑴𝑨𝑵𝑫 𝑪𝑬𝑵𝑻𝑹𝑬 〙••⩵꙰ཱི࿐\n\n';

  orderedSections.forEach((section, index) => {
    const ranks = SAMPLE_NAME_ORDER.get(section.key);
    section.commands.sort((a, b) => {
      const rankA = ranks?.get(normalizeCommandName(a.name));
      const rankB = ranks?.get(normalizeCommandName(b.name));
      if (rankA !== undefined && rankB !== undefined) return rankA - rankB;
      if (rankA !== undefined) return -1;
      if (rankB !== undefined) return 1;
      return String(a.name).localeCompare(String(b.name), undefined, { numeric: true, sensitivity: 'base' });
    });
    menu += ` ╭═━⪩ 〖  ${section.display}  〗═•━•⩵꙰ཱི࿐\n`;
    section.commands.forEach(command => {
      menu += ` │❍ ${styleCommandName(command.name)}\n`;
    });
    menu += ' ╰━━━━━━━━━━•⩵꙰ཱི࿐\n\n';
    if ((index + 1) % 3 === 0 && index + 1 < orderedSections.length) {
      menu += `${readmore}\n`;
    }
  });

  menu += `\n${botFooter} • ${styleCommandName(ownerName)}\n${botFooter}\n${botTitle} IS ON FIRE`;
  return menu;
}

function getThumbnail() {
  const customPath = path.join(__dirname, '../../data/custom_menu.jpg');
  if (fs.existsSync(customPath)) {
    try { return fs.readFileSync(customPath); } catch {}
  }
  const defaults = [
    path.join(__dirname, '../../utils/menu1.jpg'),
    path.join(__dirname, '../../utils/menu2.jpg'),
    path.join(__dirname, '../../utils/menu3.jpg')
  ];
  const available = defaults.filter(file => {
    try { return fs.existsSync(file); } catch { return false; }
  });
  if (!available.length) return null;
  try { return fs.readFileSync(available[Math.floor(Math.random() * available.length)]); } catch { return null; }
}

/* ── block formatting for styles 1 and 3 ────────────────────────────────────
   From top to bottom: every line is prefixed with "> " and the whole menu sits
   inside a code block. Style 2 (native flow) does NOT go through this — it keeps
   the plain menuText it has always used. */
function applyMenuBlock(text) {
  const body = String(text)
    .split('\n')
    .map(line => {
      if (!line.length) return '> ';
      return line.startsWith('> ') ? line : '> ' + line.replace(/^ /, '');
    })
    .join('\n');
  return '```\n' + body + '\n```';
}

/* ── Style 3 — the text design (blockquote lines kept as written) ────────── */
function buildTextDesign(commandList, totalCount) {
  const prefix = config.prefix || '.';
  const bot = config.botName || 'ASTRO X ULTRA';
  const ownerName = (Array.isArray(config.ownerName) ? config.ownerName[0] : config.ownerName) || 'blacklord';
  const { getModeLabel } = require('../../utils/botMode');
  const readmore = String.fromCharCode(8206).repeat(4001);

  const groups = new Map(MENU_ORDER.sections.map(section => [section.key, []]));
  const extraSections = new Map();
  for (const command of commandList) {
    const normalizedName = normalizeCommandName(command.name);
    const category = String(command.category || 'general').toLowerCase();
    const sectionKey = SAMPLE_NAME_SECTION.get(normalizedName) || CATEGORY_TO_SECTION[category];
    if (groups.has(sectionKey)) {
      groups.get(sectionKey).push(command);
    } else {
      const key = `extra:${category}`;
      if (!extraSections.has(key)) {
        extraSections.set(key, {
          key,
          label: category.replace(/[-_]/g, ' ').toUpperCase(),
          display: styleCommandName(category.replace(/[-_]/g, ' ').toUpperCase()),
          commands: []
        });
      }
      extraSections.get(key).commands.push(command);
    }
  }
  const ordered = MENU_ORDER.sections
    .map(section => ({ ...section, commands: groups.get(section.key) }))
    .filter(section => section.commands.length > 0)
    .concat([...extraSections.values()].sort((a, b) => a.label.localeCompare(b.label)));
  for (const section of ordered) {
    const ranks = SAMPLE_NAME_ORDER.get(section.key);
    section.commands.sort((a, b) => {
      const rankA = ranks?.get(normalizeCommandName(a.name));
      const rankB = ranks?.get(normalizeCommandName(b.name));
      if (rankA !== undefined && rankB !== undefined) return rankA - rankB;
      if (rankA !== undefined) return -1;
      if (rankB !== undefined) return 1;
      return String(a.name).localeCompare(String(b.name), undefined, { numeric: true, sensitivity: 'base' });
    });
  }

  let menu = `•━═〘 ${mapLetters(bot.toUpperCase(), SERIF_ITALIC_UPPER, SERIF_BOLD_UPPER)}〙═━•\n\n`;
  menu += '> ╭═━⪩ 〘 SYSTEM INFO 〙•━•⩵꙰ཱི࿐\n';
  menu += ` │⫹⫺ 𝗕𝗢𝗧:〖${mapLetters(bot.toUpperCase(), SERIF_ITALIC_UPPER, SERIF_BOLD_UPPER)}〗\n`;
  menu += ` │⫹⫺ 𝗗𝗘𝗩: ${ownerName}\n`;
  menu += ` │⫹⫺ 𝗩𝗘𝗥𝗦𝗜𝗢𝗡: 𝐕${config.version || '3.0.0'}\n`;
  menu += ` │⫹⫺ 𝗠𝗢𝗗𝗘: ${styleCommandName(getModeLabel())}\n`;
  menu += ` │⫹⫺ 𝗣𝗟𝗔𝗧𝗙𝗢𝗥𝗠: ${styleCommandName(detectPlatform())}\n`;
  menu += ` │⫹⫺ 𝗨𝗣𝗧𝗜𝗠𝗘: ${formatUptime()}\n`;
  menu += ` │⫹⫺ 𝗢𝗪𝗡𝗘𝗥: ${styleCommandName(ownerName)}\n`;
  menu += '> ╰━ ━ ━ ━ ━ ━ ━ ━ ━ ━ ━•⩵꙰ཱི࿐\n';
  menu += `${readmore}\n`; // Read more — the command list collapses behind the button
  menu += '        〘 𝐂𝐎𝐌𝐌𝐀𝐍𝐃𝐒〙 \n    \n';

  ordered.forEach(section => {
    const label = String(section.label || section.key || '').toUpperCase();
    menu += `    •━══〘${label}  〙══━•\n    \n`;
    section.commands.forEach(command => {
      menu += `    ⪨ ${styleCommandName(command.name)}\n`;
    });
    menu += '\n';
  });

  menu += `    ${totalCount} commands\n\n`;
  menu += '> ┗❐━ ━ ━ ━ ━ ━ ━ ━ ━ ━•⩵꙰ཱི࿐';
  return menu;
}

/* The owner-card quote, written into the payload rather than passed as `quoted`.
   gifted-btns relays its buttons message instead of calling sock.sendMessage, so a
   send-time quote never reaches the buttons menu — this does. */
function quoteFields() {
  const card = ownerCard();
  return {
    stanzaId: 'FakeID12345',
    participant: (card.key && card.key.participant) || '0@s.whatsapp.net',
    remoteJid: (card.key && card.key.remoteJid) || 'status@broadcast',
    quotedMessage: card.message
  };
}

module.exports = {
  name: 'menu',
  aliases: ['menulist', 'fullmenu'],
  category: 'general',
  description: 'Show all available commands',
  usage: '.menu',
  async execute(sock, msg, args, extra) {
    try {
      const commands = loadCommands();
      const menuCommands = [];
      commands.forEach((command, name) => {
        if (command && name !== undefined && name !== null) {
          menuCommands.push({ name: String(name), category: command.category });
        }
      });

      const loadingMsg = await sock.sendMessage(extra.from, { text: applyFont(`⏳ ${config.botName || 'ASTRO X ULTRA'} IS HERE...`) }, { quoted: msg });
      const markDone = () => sock.sendMessage(extra.from, {
        text: applyFont(`✅ ${config.botName || 'ASTRO X ULTRA'} IS HERE`),
        edit: loadingMsg.key
      }).catch(() => {});
      const msgTimestamp = msg.messageTimestamp ? msg.messageTimestamp * 1000 : Date.now();
      const speedMs = Date.now() - msgTimestamp;
      const menuText = applyFont(buildMenuText(menuCommands, menuCommands.length, speedMs));
      const thumbnail = getThumbnail();
      const botName = config.botName || 'ASTRO X ULTRA';
      const ownerName = (Array.isArray(config.ownerName) ? config.ownerName[0] : config.ownerName) || 'blacklord';
      const repoUrl = config.social?.github || 'https://github.com/blacklorddev15/Weuh';
      const chatId = extra.from;
      const footer = `Powered by ${ownerName}`;
      const style = getMenuStyle();
      const siteUrl = config.social?.website || repoUrl;

      if (style === '1') {
        const prefix = config.prefix || '.';
        const quotedMenuText = applyMenuBlock(menuText);
        await sendButtons(sock, chatId, {
          image: thumbnail ? { buffer: thumbnail, mimetype: 'image/jpeg' } : undefined,
          text: quotedMenuText,
          footer,
          mentions: [extra.sender],
          contextInfo: {
            ...quoteFields(),
            externalAdReply: {
              showAdAttribution: false,
              title: botName,
              body: ownerName,
              thumbnail,
              sourceUrl: siteUrl,
              mediaType: 1,
              renderLargerThumbnail: true
            }
          },
          buttons: [
            { name: 'cta_url', buttonParamsJson: JSON.stringify({ display_text: '🌐 𝚆𝙴𝙱𝚂𝙸𝚃𝙴', url: siteUrl }) },
            { id: `${prefix}ping`, text: '❍ 𝙿𝙸𝙽𝙶' }
          ]
        }, { quoted: ownerCard() });
        await markDone();
      } else if (style === '2') {
        try {
          const message = generateWAMessageFromContent(chatId, {
            viewOnceMessage: {
              message: {
                interactiveMessage: {
                  body: { text: null },
                  footer: { text: menuText },
                  nativeFlowMessage: { buttons: [{ text: null }] }
                }
              }
            }
          }, { quoted: msg, userJid: sock.user?.id });
          await sock.relayMessage(chatId, message.message, { messageId: message.key.id });
        } catch {
          await sock.sendMessage(chatId, { text: menuText, mentions: [extra.sender] }, { quoted: msg });
        }
        await markDone();
      } else if (style === '3') {
        // Text design — it carries its own glyphs, so it is sent exactly as written
        // (no applyFont on top of it), with the same random image as style 1.
        const designText = applyMenuBlock(buildTextDesign(menuCommands, menuCommands.length));
        const image = getThumbnail();
        if (image) {
          await sock.sendMessage(chatId, { image, caption: designText, mentions: [extra.sender] }, { quoted: ownerCard(), keepQuote: true });
        } else {
          await sock.sendMessage(chatId, { text: designText, mentions: [extra.sender] }, { quoted: ownerCard(), keepQuote: true });
        }
        await markDone();
      } else {
        await sock.sendMessage(chatId, { text: menuText, mentions: [extra.sender] }, { quoted: msg });
        await markDone();
      }
    } catch (error) {
      console.error('Menu error:', error);
      await extra.reply(`❌ Error: ${error.message}`);
    }
  }
};
