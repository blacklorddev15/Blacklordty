/**
 * checkban — check whether a number is banned on WhatsApp.
 * Ported from the Astro Inc. build.
 *
 * Needs BANCHECK_API_KEY in .env. Optional: BANCHECK_API_URL, BANCHECK_ENGINE.
 */
const axios = require('axios');
const config = require('../../config');

const SKIP_KEYS = ['messageContextInfo', 'protocolMessage', 'senderKeyDistributionMessage'];
const WRAPPERS = ['ephemeralMessage', 'viewOnceMessage', 'viewOnceMessageV2', 'viewOnceMessageV2Extension', 'documentWithCaptionMessage'];

function resolveContent(message) {
  if (!message) return null;
  const keys = Object.keys(message).filter(k => !SKIP_KEYS.includes(k));
  const top = keys[0];
  if (!top) return null;
  if (WRAPPERS.includes(top)) return message[top]?.message || null;
  return message;
}

/* The sender of the message being replied to, when no number is typed. */
function quotedSender(msg) {
  const content = resolveContent(msg && msg.message);
  if (!content) return '';
  const keys = Object.keys(content).filter(k => !SKIP_KEYS.includes(k));
  const ctx = keys.length ? content[keys[0]]?.contextInfo : null;
  const jid = ctx?.participant || ctx?.remoteJid || '';
  return String(jid).split('@')[0].split(':')[0];
}

module.exports = {
  name: 'checkban',
  aliases: ['bancheck', 'banned', 'isbanned'],
  category: 'general',
  description: 'Check if a WhatsApp number is banned',
  usage: '.checkban <number>  (or reply to a message to check that sender)',
  async execute(sock, msg, args, extra) {
    const prefix = config.prefix || '.';
    try {
      const raw = args.length ? args.join('') : quotedSender(msg);
      const number = String(raw || '').replace(/\D/g, '');
      if (!number) {
        return extra.reply(`📱 *Ban Check*\n\nUsage: ${prefix}checkban <number>\nExample: ${prefix}checkban 254712345678\n_Tip: reply to a message to check its sender._`);
      }
      if (!/^\d{10,15}$/.test(number)) {
        return extra.reply('❌ Invalid number. Use the country code, for example 254712345678.');
      }

      const apiKey = process.env.BANCHECK_API_KEY || '';
      const apiUrl = process.env.BANCHECK_API_URL || 'https://baron0.com/api/v2/check';
      const engine = process.env.BANCHECK_ENGINE || 'Baron0 v2';
      if (!apiKey) {
        return extra.reply('❌ Ban checker is not configured. Add *BANCHECK_API_KEY* to .env.');
      }

      await extra.react('🔎');
      const { data } = await axios.post(apiUrl, { number: `+${number}` }, {
        headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
        timeout: 30000
      });

      if (data?.banned === true || data?.is_banned === true || data?.status === 'banned') {
        return extra.reply(
          `📱 Number: +${number}\n🚫 Status: *BANNED*\n📝 Reason: ${data.reason || data.violation_label || '—'}\n🔒 Ban Type: ${data.ban_type || '—'}\n⚙️ Engine: ${engine}`
        );
      }
      if (data?.error) {
        return extra.reply(`⚠️ ${String(data.error).toUpperCase()}\n⚙️ Engine: ${engine}`);
      }
      return extra.reply(`📱 Number: +${number}\n✅ Status: *NOT BANNED*\n⚙️ Engine: ${engine}`);
    } catch (error) {
      const detail = error.response?.data?.error || error.message;
      await extra.reply(`❌ checkban error: ${detail}`);
    }
  }
};
