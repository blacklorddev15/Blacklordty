const database = require(require('path').join(global.__CORE__, 'database'));
const config = require('../../config');
const { loadCommands } = require('../../utils/commandLoader');
const stickerCommands = require('../../utils/stickerCommands');
const VALID_ACTIONS = ['promote', 'demote', 'kick', 'warn', 'add', 'tagall', 'mute'];
const ACTION_DESC = {
  promote: 'Promotes the quoted member to admin',
  demote: 'Demotes the quoted admin to member',
  kick: 'Removes the quoted member from the group',
  warn: 'Warns the quoted member (kicks on max warns)',
  add: 'Re-adds the quoted member to the group',
  tagall: 'Tags all group members',
  mute: 'Mutes the quoted member (bot ignores them)'
};

// Keys that must be skipped when looking for the real message type
const SKIP_KEYS = ['messageContextInfo', 'protocolMessage', 'senderKeyDistributionMessage'];
const WRAPPERS = ['ephemeralMessage', 'viewOnceMessage', 'viewOnceMessageV2', 'viewOnceMessageV2Extension', 'documentWithCaptionMessage'];
function resolveContent(message) {
  if (!message) return null;
  const keys = Object.keys(message).filter(k => !SKIP_KEYS.includes(k));
  const top = keys[0];
  if (!top) return null;
  if (WRAPPERS.includes(top)) return message[top]?.message || null;
  return message;
}
function extractContextInfo(msg) {
  const content = resolveContent(msg.message);
  if (!content) return null;
  // Find the real message type, skipping protocol/meta keys
  const keys = Object.keys(content).filter(k => !SKIP_KEYS.includes(k));
  const top = keys[0];
  if (!top) return null;
  return content[top]?.contextInfo || null;
}
function toBase64Hash(raw) {
  if (!raw) return null;
  if (Buffer.isBuffer(raw)) return raw.toString('base64');
  if (typeof raw === 'object') return Buffer.from(Object.values(raw)).toString('base64');
  return null;
}
module.exports = {
  name: 'setsticker',
  aliases: ['stickeraction', 'stickertrigger'],
  category: 'admin',
  description: 'Bind a sticker to a group action, or to any command (groups and DMs)',
  usage: '.setsticker <action|command> — reply to a sticker\n.setsticker list\n.setsticker clear <action|command>',
  // Deliberately NOT groupOnly/adminOnly — the guard in execute() allows a DM for the
  // owner and a group for admins, which is what lets a sticker be bound in either place.
  async execute(sock, msg, args, extra) {
    try {
      const inGroup = extra.isGroup === true;
      const isOwnerOrSudo = extra.isOwner === true || extra.isSudo === true;
      if (!inGroup && !isOwnerOrSudo) {
        return extra.reply('❌ *Private chats:* only the owner can bind stickers here.\n_Group admins can do it inside a group._');
      }
      if (inGroup && extra.isAdmin !== true && !isOwnerOrSudo) {
        return extra.reply('❌ Only *group admins* (or the owner) can bind stickers.');
      }

      const sub = args[0]?.toLowerCase();
      if (!sub) {
        const actionLines = VALID_ACTIONS.map(a => `  • *${a}* — ${ACTION_DESC[a]}`).join('\n');
        return extra.reply(`🎭 *Set Sticker Trigger*\n━━━━━━━━━━━━━━━\n\n` + `Reply to a sticker with:\n` + `*.setsticker <action>*\n\n` + `When an admin replies to a member's message with that sticker, the action is applied to the *quoted member*.\n\n` + `*Actions:*\n${actionLines}\n\n` + `*Other commands:*\n` + `  .setsticker list\n` + `  .setsticker clear <action>\n\n` + `*Bind a sticker to any command:*\n` + `  Reply to a sticker with *.setsticker menu*\n` + `  → sending that sticker then runs *.menu*\n\n` + `_Works in groups and DMs. Group actions stay group-only._`);
      }
      const groupSettings = database.getGroupSettings(extra.from);
      const stickerActions = groupSettings.stickerActions || {};
      if (sub === 'list') {
        const entries = Object.entries(stickerActions);
        const binds = Object.entries(stickerCommands.all());
        if (!entries.length && !binds.length) return extra.reply('📋 No sticker triggers set for this group.');
        const groupLines = entries.map(([action]) => `  • *${action}* → ${ACTION_DESC[action]} ✅`).join('\n');
        const bindLines = binds.map(([name]) => `  • sticker → *${config.prefix || '.'}${name}*`).join('\n');
        return extra.reply(`📋 *Sticker Triggers*\n━━━━━━━━━━━━━━━\n\n` + (entries.length ? `*Group actions:*\n${groupLines}\n\n` : '') + (binds.length ? `*Command stickers:*\n${bindLines}\n\n` : '') + `_Reply to a member's message with an action sticker, or just send a command sticker._`);
      }
      if (sub === 'clear') {
        const toClear = args[1]?.toLowerCase();
        if (!toClear) {
          return extra.reply(`❌ Specify what to clear:\n  • a group action: ${VALID_ACTIONS.join(', ')}\n  • or a bound command, e.g. *.setsticker clear menu*`);
        }
        let cleared = false;
        if (stickerActions[toClear]) {
          delete stickerActions[toClear];
          database.updateGroupSettings(extra.from, {
            stickerActions
          });
          cleared = true;
        }
        if (stickerCommands.remove(toClear)) cleared = true;
        if (!cleared) return extra.reply(`❌ Nothing set for *${toClear}*.`);
        return extra.reply(`✅ Sticker trigger for *${toClear}* cleared.`);
      }
      if (!VALID_ACTIONS.includes(sub)) {
        // Not a group action — allow binding a sticker to any known command.
        const known = new Set([...loadCommands().keys()]);
        known.delete('setsticker');
        if (!known.has(sub)) {
          return extra.reply(`❌ Unknown action or command: *${sub}*\n\n*Group actions:* ${VALID_ACTIONS.join(', ')}\n_…or bind any command, e.g. *.setsticker menu*_`);
        }
        const bindCtx = extractContextInfo(msg);
        const bindSticker = bindCtx?.quotedMessage?.stickerMessage;
        if (!bindSticker) {
          return extra.reply(`❌ Please *reply to a sticker* to bind it!\nExample: reply to a sticker with *.setsticker ${sub}*`);
        }
        if (!toBase64Hash(bindSticker.fileSha256) && !toBase64Hash(bindSticker.fileEncSha256)) {
          return extra.reply('❌ Could not read sticker fingerprint. Try a different sticker.');
        }
        stickerCommands.set(sub, bindSticker);
        return extra.reply(`✅ *Sticker → command set!*\n\n` + `⚡ Sending this sticker now runs: *${config.prefix || '.'}${sub}*\n` + `📌 Remove it with *.setsticker clear ${sub}*`);
      }
      if (!inGroup) {
        return extra.reply(`❌ *${sub}* is a group action, so it can only be set inside a group.\n\nIn a private chat bind a *command* instead — reply to a sticker with *.setsticker menu* and sending it then runs *.menu* anywhere.`);
      }
      const ctx = extractContextInfo(msg);
      const quotedSticker = ctx?.quotedMessage?.stickerMessage;
      if (!quotedSticker) {
        return extra.reply('❌ Please *reply to a sticker* to set it as the trigger!');
      }

      // Use fileSha256 as primary, fileEncSha256 as fallback
      const hash = toBase64Hash(quotedSticker.fileSha256) || toBase64Hash(quotedSticker.fileEncSha256);
      if (!hash) return extra.reply('❌ Could not read sticker fingerprint. Try a different sticker.');

      // Store both hashes so the trigger can match on either
      stickerActions[sub] = {
        fileSha256: toBase64Hash(quotedSticker.fileSha256) || null,
        fileEncSha256: toBase64Hash(quotedSticker.fileEncSha256) || null
      };
      database.updateGroupSettings(extra.from, {
        stickerActions
      });
      return extra.reply(`✅ *Sticker trigger set!*\n\n` + `⚡ Action: *${sub}*\n` + `📌 ${ACTION_DESC[sub]}\n\n` + `_When an admin replies to a member's message with this sticker, *${sub}* will be applied to the quoted member._`);
    } catch (error) {
      await extra.reply(`❌ Error: ${error.message}`);
    }
  }
};