/**
 * GetSession Command - Owner only
 *
 * Sends the bot's current creds.json as a self-contained Astro-X~<base64> session
 * ID — the exact form this build accepts as SESSION_ID with no server fetch — and
 * keeps .env's SESSION_ID in sync so it is also copyable from the panel's file
 * manager. Every step is logged to the panel console, and every failure replies
 * with the reason instead of going quiet.
 */

const fs = require('fs');
const path = require('path');
const config = require('../../config');

const SESSION_PREFIX = 'Astro-X~';

function candidateCredsPaths() {
  const roots = [];
  const configured = config.sessionName ? String(config.sessionName).trim() : '';
  if (configured) roots.push(configured);
  roots.push('session'); // index.js falls back to this when sessionName is empty
  const out = [];
  for (const root of roots) {
    out.push(path.join(__dirname, '..', '..', root, 'creds.json'));
    out.push(path.join(process.cwd(), root, 'creds.json'));
  }
  return [...new Set(out)];
}

function findCreds() {
  for (const candidate of candidateCredsPaths()) {
    try {
      if (!fs.existsSync(candidate)) continue;
      const text = fs.readFileSync(candidate, 'utf8');
      JSON.parse(text); // reject a half-written file rather than encode it
      return { path: candidate, text };
    } catch (error) {
      console.error('[getsession] skipping ' + candidate + ': ' + error.message);
    }
  }
  return null;
}

/** Keep .env's SESSION_ID equal to what we are sending. */
function syncEnv(sessionID) {
  try {
    const envPath = path.join(__dirname, '..', '..', '.env');
    if (!fs.existsSync(envPath)) return 'no .env file';
    const text = fs.readFileSync(envPath, 'utf8');
    const current = text.match(/^SESSION_ID=(.*)$/m);
    if (current && current[1].trim() === sessionID) return 'already current in .env';
    if (current) {
      fs.writeFileSync(envPath, text.replace(/^SESSION_ID=.*$/m, 'SESSION_ID=' + sessionID));
      return 'written to .env';
    }
    fs.writeFileSync(envPath, text.replace(/\s*$/, '') + '\nSESSION_ID=' + sessionID + '\n');
    return 'appended to .env';
  } catch (error) {
    return 'could not write .env (' + error.message + ')';
  }
}

module.exports = {
  name: 'getsession',
  aliases: ['sessionid', 'mysession', 'session'],
  category: 'owner',
  description: 'Send the current session as a self-contained Astro-X~<base64> ID',
  usage: '.getsession',
  ownerOnly: true,
  adminOnly: false,
  groupOnly: false,
  botAdminOnly: false,
  async execute(sock, msg, args, extra) {
    const from = (extra && extra.from) || (msg && msg.key && msg.key.remoteJid);
    // Never go quiet: try extra.reply, then the socket, and log if both fail.
    const say = async text => {
      try {
        if (extra && typeof extra.reply === 'function') return await extra.reply(text);
      } catch (error) {
        console.error('[getsession] extra.reply failed: ' + error.message);
      }
      try {
        return await sock.sendMessage(from, { text }, { quoted: msg });
      } catch (error) {
        console.error('[getsession] sendMessage failed: ' + error.message);
      }
    };

    try {
      console.log('[getsession] invoked from ' + from);
      const found = findCreds();
      if (!found) {
        console.error('[getsession] no creds.json found; looked in ' + candidateCredsPaths().join(', '));
        await say(
          '❌ *No session file found!*\n\nThe bot has no saved credentials yet — connect it first.\n\nLooked in:\n' +
            candidateCredsPaths()
              .map(p => '• ' + p)
              .join('\n')
        );
        return;
      }

      const creds = JSON.parse(found.text);
      const sessionID = SESSION_PREFIX + Buffer.from(found.text, 'utf8').toString('base64');
      const envResult = syncEnv(sessionID);
      console.log(
        '[getsession] creds=' + found.path + ' chars=' + sessionID.length + ' env=' + envResult
      );

      await say('⏳ Generating your session ID, please wait...');
      await say(
        '✅ *Session ID ready*\n\n' +
          '• Starts with: `' + SESSION_PREFIX + '`\n' +
          '• Length: ' + sessionID.length + ' characters\n' +
          '• Account: `' + ((creds.me && creds.me.id) || 'unknown') + '`\n' +
          '• Saved as SESSION_ID: ' + envResult + '\n\n' +
          'It is being sent as a separate message — long-press it to copy.\n' +
          '⚠️ Keep it secret: it *is* the account.'
      );
      // The token itself, alone, so it is easy to copy.
      await sock.sendMessage(from, { text: sessionID }, { quoted: msg });
      console.log('[getsession] session ID sent (' + sessionID.length + ' chars)');
    } catch (error) {
      console.error('[getsession] failed: ' + ((error && error.stack) || error));
      await say('❌ Failed to generate session ID: ' + (error && error.message));
    }
  }
};
