/**
 * Prefix-free mode — when ON, a bare command name still runs (no prefix needed).
 * Persisted in database/bot-settings.json under `prefixfree`; handler.js reads it
 * at the prefix gate.
 */
const config = require('../../config');
const db = require('../../database');

module.exports = {
  name: 'prefixfree',
  aliases: ['setprefixfree', 'pfree'],
  category: 'owner',
  description: 'Let known commands run without the prefix',
  usage: '.prefixfree on|off  (omit the argument to toggle)',
  ownerOnly: true,
  async execute(sock, msg, args, extra) {
    try {
      const value = String(args[0] || '').toLowerCase();
      const current = Boolean(db.getBotSetting('prefixfree'));
      let enabled;
      if (!value || value === 'toggle') enabled = !current;
      else if (['on', 'true', '1', 'enable', 'enabled'].includes(value)) enabled = true;
      else if (['off', 'false', '0', 'disable', 'disabled'].includes(value)) enabled = false;
      else {
        return extra.reply(`❌ Usage: ${config.prefix || ''}prefixfree on|off\n_Or omit the argument to toggle._`);
      }

      db.setBotSetting('prefixfree', enabled);
      const p = config.prefix || '.';
      await extra.reply(
        `✅ *Prefix-free mode is now ${enabled ? 'ON' : 'OFF'}.*\n\n` +
        (enabled
          ? `Known commands now run without a prefix:\n  • *menu*\n  • *ping*\n  • *help*\n\n_${p}menu still works too._`
          : `Commands need the prefix again: *${p}menu*`)
      );
    } catch (error) {
      await extra.reply(`❌ Error: ${error.message}`);
    }
  }
};
